# CEEP_iD

O aplicativo de identificação de alunos do Colégio Municipal de Educação Profissional em Gestão e Meio Ambiente, em Brumado/BA.
